#include <stdio.h>
#include <stdlib.h>
#include "poly.h"
#include "Funciones_mat.h"
#include "time.h"
#include "pynq_api.h"
#include "Funciones_HW.h"
#include "sample.h"
#include "poly.h"
#include "rng.h"
#include "api.h"
#include "kem.h"

int main(int argc, char** argv){
	uint16_t r[NTRU_N];
	uint16_t h[NTRU_N];
	uint16_t e[NTRU_N];
	uint16_t e_HW[NTRU_N];
	poly x1, x2, x3, x4, x5, x6;
	poly* poly_r = &x1;
	poly* poly_m = &x4;
	poly* poly_h = &x2;
	poly* poly_e = &x3;
	poly* liftm = &x5;
	poly* ct = &x6;

	int DBG = 2;
	int N_TEST = 1;
	int N_COEFFS = 10;
	int comp_SW = 0;
	int comp_HW = 0;
	int fallos = 0;
	int fallos_HW = 0;

	unsigned char rm_seed[NTRU_SAMPLE_RM_BYTES];
	unsigned char pk[CRYPTO_PUBLICKEYBYTES], sk[CRYPTO_SECRETKEYBYTES];
	unsigned char c[CRYPTO_CIPHERTEXTBYTES];

	unsigned long long tic = 0, toc;
	unsigned long long tiempo_total_mult_1 = 0;
	unsigned long long tiempo_total_mult_2 = 0;
	unsigned long long tiempo_total_mult_hw = 0;
	unsigned long long tiempo_total_enc_1 = 0;
	unsigned long long tiempo_total_enc_2 = 0;
	unsigned long long tiempo_total_enc_hw = 0;

	for (int arg = 1; arg < argc; arg++) {
		if (argv[arg][0] == '-') {
			if (argv[arg][1] == 'h') {
				printf("\nUsage: ./Test [-h] [-t <num_test>] [-n <num_coeffs>] [-d <dbg_level>] \n\n");
				printf("DBG == 1: Se muestra cada 20 test. Minimizar la impresion por pantalla \n");
				printf("DBG == 2: Se muestran todos los tiempos de cada una de las partes. Opcion por defecto. \n");
				printf("DBG == 3: Se muestran los coeficientes del SW / HW. \n");
				printf("DBG == 4: Se muestran las operaciones de multiplicacion SW. \n");
				printf("DBG == 5: Se muestran las operaciones y los coeficientes del HW. \n");
				printf("DBG == 6: SIN USO. \n");
				printf("DBG == 7: Se muestra la semilla, numero de 1's y -1's en r. Tambien muestra los coeficientes de r y h. \n");
				return PYNQ_SUCCESS;
			}
			else if (argv[arg][1] == 'd') {
				if (arg < argc - 1) DBG = atoi(argv[arg + 1]);
			}
			else if (argv[arg][1] == 't') {
				if (arg < argc - 1) N_TEST = atoi(argv[arg + 1]);
			}
			else if (argv[arg][1] == 'n') {
				if (arg < argc - 1) N_COEFFS = atoi(argv[arg + 1]);
			}
			else {
				printf("\nunknow option: %s\n", argv[arg]);
			}
		}
	}

	// ----- INICIALIZACION HARDWARE ----- //
	load_ntru_hw(DBG);
	PYNQ_SHARED_MEMORY shm_1, shm_2;
	PYNQ_allocatedSharedMemory(&shm_1, sizeof(int) * NTRU_N, 1);
	PYNQ_allocatedSharedMemory(&shm_2, sizeof(int) * NTRU_N, 1);
	PYNQ_AXI_DMA dma;
	PYNQ_openDMA(&dma, 0x40400000);


	printf(" \n --- INICIO TESTS --- \n \n ");
	
	for (int n_test = 1; n_test <= N_TEST; n_test++) {

		if (DBG == 2) printf(" --- TEST %d --- \n ", n_test);

		// --------- PARTE SOFTWARE --------------------- //
		tic = PYNQ_Wtime();
			crypto_kem_keypair(pk, sk);
		toc = PYNQ_Wtime() - tic;
		if (DBG == 10) {
			unsigned long long L = CRYPTO_PUBLICKEYBYTES;
			printf("\n pk: ");
			for (unsigned long long i = 0; i < L; i++) printf("%02X", pk[i]);
			printf("\n");
		}
		if (DBG == 2) printf(" Generacion claves (pk / sk) \t ... \t (%6llu us.) \n ", toc);

		tic = PYNQ_Wtime();
			// Generacion r
			randombytes(rm_seed, NTRU_SAMPLE_RM_BYTES);
			if(DBG == 7) printf("\n \n %u \n", (unsigned int)rm_seed);
			sample_rm(poly_r, poly_m, rm_seed);
			poly_Z3_to_Zq(poly_r);
			poly_to_array(r, poly_r);
			num_ones_minus(r, DBG);

			// Generacion h
			poly_Rq_sum_zero_frombytes(poly_h, pk);
			poly_to_array(h, poly_h);
			//array_aleatorio(h);
			//array_to_poly(h, poly_h);

			if (DBG == 7) {
				for (int i = 0; i < N_COEFFS; i++) {
					printf("\n %d -> %d \t %d \t %d \t %d", i, poly_r->coeffs[i], r[i], poly_h->coeffs[i], h[i]);
				}
			}
		toc = PYNQ_Wtime() - tic;
		if (DBG == 2) printf(" Generacion r / h (SW) \t ... \t (%6llu us.) \n ", toc);

		tic = PYNQ_Wtime();
			poly_Rq_mul_DBG(poly_e, poly_r, poly_h, DBG);
		toc = PYNQ_Wtime() - tic;
		tiempo_total_mult_1 += toc;
		tiempo_total_enc_1 += toc;
		if (DBG == 2) printf(" Mult. v. NTRU 3 Ronda (SW) \t ... \t (%6llu us.) \n ", toc);

		tic = PYNQ_Wtime();
			array_mult_v16bits(e, r, h, DBG);
			//array_mult(e, r, h, DBG);
		toc = PYNQ_Wtime() - tic;
		tiempo_total_mult_2 += toc;
		tiempo_total_enc_2 += toc;
		if (DBG == 2) printf(" Mult. v. NTRU Encrypt (SW) \t ... \t (%6llu us.) \n ", toc);

		tic = PYNQ_Wtime();
			comp_SW = comprobar_igualdad(poly_e, e);
			if (comp_SW != 0) fallos++;
		toc = PYNQ_Wtime() - tic;
		if (DBG == 2 && comp_SW == 0) printf(" Comprobar Igualdad (SW) \t ... \t (%6llu us.) OK \n ", toc);
		if (DBG == 2 && comp_SW != 0) printf(" Comprobar Igualdad (SW) \t ... \t (%6llu us.) FAIL \n ", toc);

		// --------- PARTE HARDWARE --------------------- //

		tic = PYNQ_Wtime();
			ntru_mult_ms2xs(r, h, e_HW, shm_1, shm_2, dma, DBG);
		toc = PYNQ_Wtime() - tic;
		tiempo_total_mult_hw += toc;
		tiempo_total_enc_hw += toc;
		if (DBG == 2) printf(" Mult. HARDWARE (HW) \t \t ... \t (%6llu us.) \n ", toc);

		tic = PYNQ_Wtime();
			comp_HW = comprobar_igualdad(poly_e, e_HW);
			if (comp_HW != 0) fallos_HW++;
		toc = PYNQ_Wtime() - tic;
		if (DBG == 2 && comp_HW == 0) printf(" Comprobar Igualdad (HW) \t ... \t (%6llu us.) OK \n ", toc);
		if (DBG == 2 && comp_HW != 0) printf(" Comprobar Igualdad (HW) \t ... \t (%6llu us.) FAIL \n ", toc);

		if (DBG == 3 || DBG == 5) {
			printf("\n i -> poly_r->coeffs[i] \t poly_h->coeffs[i] \t poly_e->coeffs[i] \t e[i] \t e_HW[i]");
			for (int i = 0; i < N_COEFFS; i++) {
				printf("\n %d -> %d \t %d \t %d \t %d \t %d", i, poly_r->coeffs[i], poly_h->coeffs[i], poly_e->coeffs[i], e[i], e_HW[i]);
			}
		}

		// --------- PARTE SOFTWARE RESTO CIFRADO --------------------- //
		tic = PYNQ_Wtime();
			poly_lift(liftm, poly_m);
			for (int i = 0; i < NTRU_N; i++)
				ct->coeffs[i] = ct->coeffs[i] + liftm->coeffs[i];
			poly_Rq_sum_zero_tobytes(c, ct);
		toc = PYNQ_Wtime() - tic;
		tiempo_total_enc_1 += toc;
		tiempo_total_enc_2 += toc;
		tiempo_total_enc_hw += toc;
		if (DBG == 2) printf(" Resto Cifrado (SW) \t \t ... \t (%6llu us.) \n ", toc);

		if (DBG == 1) {
			if(n_test % 20 == 0 || n_test == 1) printf("\n %d ", n_test);
		}

	}

	printf("\n VALORES MEDIOS \n \n");
	printf(" Mult. v. NTRU 3 Ronda (SW) \t ... \t (%6llu us.) \n", tiempo_total_mult_1 / N_TEST);
	printf(" Mult. v. NTRU Encrypt (SW) \t ... \t (%6llu us.) \n", tiempo_total_mult_2 / N_TEST);
	printf(" Mult. v. NTRU HARDWARE (HW) \t ... \t (%6llu us.) \n \n", tiempo_total_mult_hw / N_TEST);
	printf(" ENC. v. NTRU 3 Ronda (SW) \t ... \t (%6llu us.) \n", tiempo_total_enc_1 / N_TEST);
	printf(" ENC. v. NTRU Encrypt (SW) \t ... \t (%6llu us.) \n", tiempo_total_enc_2 / N_TEST);
	printf(" ENC. v. NTRU HARDWARE (HW) \t ... \t (%6llu us.) \n \n", tiempo_total_enc_hw / N_TEST);
	printf(" ACELERACION Mult.:  %f \n", (float)tiempo_total_enc_1 / (float)tiempo_total_enc_hw);
	printf(" ACELERACION ENC:  %f \n", (float)tiempo_total_enc_1 / (float)tiempo_total_enc_hw);
	printf(" FALLOS: %d \n", fallos);
	printf(" FALLOS_HW: %d \n", fallos_HW);

	PYNQ_closeDMA(&dma);
	PYNQ_freeSharedMemory(&shm_1);
	PYNQ_freeSharedMemory(&shm_2);

	return PYNQ_SUCCESS;
}