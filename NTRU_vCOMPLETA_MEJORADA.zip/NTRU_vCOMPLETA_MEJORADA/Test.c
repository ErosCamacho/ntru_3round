#include <stdio.h>
#include <stdlib.h>
#include "poly.h"
#include "Funciones_mat.h"
#include "time.h"
#include "pynq_api.h"
#include "Funciones_HW.h"
#include "sample.h"
#include "poly.h"
#include "rng.h"
#include "api.h"
#include "kem.h"
#include "Funciones_gen_enc_dec.h"

int main(int argc, char** argv){
	uint16_t r[NTRU_N];
	uint16_t h[NTRU_N];
	uint16_t e[NTRU_N];
	uint16_t e_HW[NTRU_N];
	poly x1, x2, x3, x4, x5, x6;
	poly* poly_r = &x1;
	poly* poly_m = &x4;
	poly* poly_h = &x2;
	poly* poly_e = &x3;
	poly* liftm = &x5;

	int DBG = 1;
	int N_TEST = 1;
	int N_COEFFS = 10;
	int comp_SW = 0;
	int comp_HW = 0;
	int fallos = 0;
	int fallos_HW = 0;
	int comp_crypto = 0;
	int fallos_crypto = 0;

	//unsigned char rm_seed[NTRU_SAMPLE_RM_BYTES];
	unsigned char pk[CRYPTO_PUBLICKEYBYTES], sk[CRYPTO_SECRETKEYBYTES];
	unsigned char ss[CRYPTO_BYTES], ss_dec[CRYPTO_BYTES], ss_dec_hw[CRYPTO_BYTES];
	unsigned char ss_enc_kem[CRYPTO_BYTES], ss_dec_kem[CRYPTO_BYTES];
	unsigned char c[CRYPTO_CIPHERTEXTBYTES], c_libntru[CRYPTO_CIPHERTEXTBYTES], c_hw[CRYPTO_CIPHERTEXTBYTES];
	unsigned char ct[CRYPTO_CIPHERTEXTBYTES];

	unsigned long long tic = 0, toc;
	unsigned long long tiempo_mult;
	unsigned long long tiempo_enc;
	unsigned long long tiempo_dec;
	unsigned long long tiempo_total_mult_1 = 0;
	unsigned long long tiempo_total_mult_2 = 0;
	unsigned long long tiempo_total_mult_hw = 0;
	unsigned long long tiempo_total_enc_1 = 0;
	unsigned long long tiempo_total_enc_2 = 0;
	unsigned long long tiempo_total_enc_hw = 0;
	unsigned long long tiempo_total_dec = 0;
	unsigned long long tiempo_total_dec_hw = 0;

	for (int arg = 1; arg < argc; arg++) {
		if (argv[arg][0] == '-') {
			if (argv[arg][1] == 'h') {
				printf("\nUsage: ./Test [-h] [-n <num_test>] [-d <DBG>] [-c <num_coeffs_DBG>] \n\n");
				printf("\nANALISIS TEMPORAL : \n");
				printf("DBG == 0: Se muestra cada 20 test. Minimizar la impresion por pantalla \n");
				printf("DBG == 1: Se muestran todos los tiempos de cada una de las partes. Opcion por defecto. \n");
				printf("DBG == 2: Muestra los tiempos detallados por partes. \n");
				printf("\nANALISIS FUNCIONAL : \n");
				printf("DBG == 3: Se muestran los coeficientes del SW / HW. \n");
				printf("DBG == 4: Se muestran las operaciones de multiplicacion SW. \n");
				printf("DBG == 5: Se muestran las operaciones y los coeficientes del HW. \n");
				printf("DBG == 6: Se muestra la clave publica. \n");
				printf("DBG == 7: Se muestra la semilla, numero de 1's y -1's en r. Tambien muestra los coeficientes de r y h. \n");
				printf("DBG == 8: Se muestran las operaciones de multiplicacion SW 3 ROUND. \n");
				printf("DBG == 9: Se muestra el mensaje cifrado por 3 ROUND, LIBNTRU, HW. \n \n");
				printf("DBG == 10: Se muestra el HASH de rm para version kem y personal, enc y dec. \n \n");
				return PYNQ_SUCCESS;
			}
			else if (argv[arg][1] == 'd') {
				if (arg < argc - 1) DBG = atoi(argv[arg + 1]);
			}
			else if (argv[arg][1] == 'n') {
				if (arg < argc - 1) N_TEST = atoi(argv[arg + 1]);
			}
			else if (argv[arg][1] == 'c') {
				if (arg < argc - 1) N_COEFFS = atoi(argv[arg + 1]);
			}
			else {
				printf("\nunknow option: %s\n", argv[arg]);
			}
		}
	}

	printf(" \n --- INICIALIZACION HARDWARE --- \n ");

	// ----- INICIALIZACION HARDWARE ----- //
	load_ntru_hw(DBG);
	PYNQ_SHARED_MEMORY shm_1, shm_2;
	PYNQ_allocatedSharedMemory(&shm_1, sizeof(int) * NTRU_N, 1);
	PYNQ_allocatedSharedMemory(&shm_2, sizeof(int) * NTRU_N, 1);
	PYNQ_AXI_DMA dma;
	PYNQ_openDMA(&dma, 0x40400000);


	printf(" \n --- INICIO TESTS --- \n ");
	
	for (int n_test = 1; n_test <= N_TEST; n_test++) {

		if (DBG == 1 || DBG == 2) printf("\n --- TEST %d --- \n ", n_test);

		// -------- GENERACION CLAVES ------------------- // 

		// Generar Clave Publica y Privada
		gen_keys(pk, sk, DBG);

		// --------- CIFRADO SOFTWARE --------------------- //

		unsigned char rm_seed[NTRU_SAMPLE_RM_BYTES];
		randombytes(rm_seed, NTRU_SAMPLE_RM_BYTES);

		// Generar r, h y m a partir de semillas
		gen_rhmss(r, poly_r, h, poly_h, poly_m, pk, ss, DBG, N_COEFFS, rm_seed);

		crypto_kem_enc(ct, ss_enc_kem, pk, rm_seed);

		enc_ntru_3round(c, poly_r, poly_h, poly_m, &tiempo_mult, &tiempo_enc, DBG, N_COEFFS);
		tiempo_total_mult_1 += tiempo_mult;
		tiempo_total_enc_1 += tiempo_enc;

		enc_ntru_libntru(c_libntru, r, h, poly_m, &tiempo_mult, &tiempo_enc, DBG, N_COEFFS);
		tiempo_total_mult_2 += tiempo_mult;
		tiempo_total_enc_2 += tiempo_enc;

		// --------- CIFRADO HARDWARE --------------------- //

		enc_ntru_hw(c_hw, r, h, poly_m, &tiempo_mult, &tiempo_enc, shm_1, shm_2, dma, DBG, N_COEFFS);
		tiempo_total_mult_hw += tiempo_mult;
		tiempo_total_enc_hw += tiempo_enc;

		// --------- DESCIFRADO SOFTWARE --------------------- //

		crypto_kem_dec(ss_dec_kem, ct, sk);

		dec_ntru_3round(ss_dec, c_hw, sk, &tiempo_dec, DBG, N_COEFFS);
		tiempo_total_dec += tiempo_dec;

		// --------- DESCIFRADO JARDWARE --------------------- //

		dec_ntru_hw(ss_dec_hw, c_hw, sk, &tiempo_dec, shm_1, shm_2, dma, DBG, N_COEFFS);
		tiempo_total_dec_hw += tiempo_dec;

		// ---------- CHECKEAR IGUALDADES CIFRADO -------------- //

		if (DBG == 10) {
			printf("\n ss_enc_kem: ");
			for (unsigned long long i = 0; i < CRYPTO_BYTES; i++) printf("%02X", ss_enc_kem[i]);
			printf("\n");
			printf("\n ss_dec_kem: ");
			for (unsigned long long i = 0; i < CRYPTO_BYTES; i++) printf("%02X", ss_dec_kem[i]);
			printf("\n");
			printf("\n ss: ");
			for (unsigned long long i = 0; i < CRYPTO_BYTES; i++) printf("%02X", ss[i]);
			printf("\n");
			printf("\n ss_dec: ");
			for (unsigned long long i = 0; i < CRYPTO_BYTES; i++) printf("%02X", ss_dec[i]);
			printf("\n");
			printf("\n ss_dec_hw: ");
			for (unsigned long long i = 0; i < CRYPTO_BYTES; i++) printf("%02X", ss_dec_hw[i]);
			printf("\n");
		}

		if (DBG == 9) {
			printf("\n c_kem: ");
			for (unsigned long long i = 0; i < CRYPTO_CIPHERTEXTBYTES; i++) printf("%02X", ct[i]);
			printf("\n");
			printf("\n c: ");
			for (unsigned long long i = 0; i < CRYPTO_CIPHERTEXTBYTES; i++) printf("%02X", c[i]);
			printf("\n");
			printf("\n c_libntru: ");
			for (unsigned long long i = 0; i < CRYPTO_CIPHERTEXTBYTES; i++) printf("%02X", c_libntru[i]);
			printf("\n");
			printf("\n c_HW: ");
			for (unsigned long long i = 0; i < CRYPTO_CIPHERTEXTBYTES; i++) printf("%02X", c_hw[i]);
			printf("\n");
		}


		tic = PYNQ_Wtime();
			comp_SW = comprobar_igualdad_c(c, c_libntru);
			if (comp_SW != 0) fallos++;
			comp_HW = comprobar_igualdad_c(c, c_hw);
			if (comp_HW != 0) fallos_HW++;
		toc = PYNQ_Wtime() - tic;
		if (DBG == 2 && comp_SW == 0) printf("\n Check Igualdad ENC. (SW) \t ... \t (%6llu us.) OK \n", toc);
		if (DBG == 2 && comp_SW != 0) printf("\n Check Igualdad ENC. (SW) \t ... \t (%6llu us.) FAIL \n", toc);
		if (DBG == 2 && comp_HW == 0) printf(" Check Igualdad ENC. (HW) \t ... \t (%6llu us.) OK \n ", toc);
		if (DBG == 2 && comp_HW != 0) printf(" Check Igualdad ENC. (HW) \t ... \t (%6llu us.) FAIL \n ", toc);

		comp_crypto = comprobar_igualdad_crypto(ss, ss_dec);
		if (comp_crypto != 0) fallos_crypto++;
		if ((DBG == 1 || DBG == 2) && comp_crypto == 0) printf("\n Everything works OK \n");
		if ((DBG == 1 || DBG == 2) && comp_crypto != 0) printf("\n Cryptosystem FAIL \n");

		// ---------- IMPRESION COEFICIENTES ------------ //
		if (DBG == 3 || DBG == 5) {
			printf("\n i -> poly_r->coeffs[i] \t poly_h->coeffs[i] \t poly_e->coeffs[i] \t e[i] \t e_HW[i]");
			for (int i = 0; i < N_COEFFS; i++) {
				printf("\n %d -> %d \t %d \t %d \t %d \t %d", i, poly_r->coeffs[i], poly_h->coeffs[i], poly_e->coeffs[i], e[i], e_HW[i]);
			}
		}

		// ---- REDUCCION DE ESCRITO EN PANTALLA -------- //
		if (DBG == 0) {
			if(n_test % 20 == 0 || n_test == 1) printf("\n %d ", n_test);
		}

	}


	// --------- IMPRESION DE VALORES MEDIOS ------------ //
	printf("\n\n ### --  RESULTADOS  -- ### \n");
	printf("\n VALORES MEDIOS \n \n");
	printf(" Mult. v. NTRU 3 Ronda (SW) \t ... \t (%6llu us.) \n", tiempo_total_mult_1 / N_TEST);
	printf(" Mult. v. NTRU Encrypt (SW) \t ... \t (%6llu us.) \n", tiempo_total_mult_2 / N_TEST);
	printf(" Mult. v. NTRU HARDWARE (HW) \t ... \t (%6llu us.) \n \n", tiempo_total_mult_hw / N_TEST);
	printf(" ENC. v. NTRU 3 Ronda (SW) \t ... \t (%6llu us.) \n", tiempo_total_enc_1 / N_TEST);
	printf(" ENC. v. NTRU Encrypt (SW) \t ... \t (%6llu us.) \n", tiempo_total_enc_2 / N_TEST);
	printf(" ENC. v. NTRU HARDWARE (HW) \t ... \t (%6llu us.) \n \n", tiempo_total_enc_hw / (unsigned long long)N_TEST);
	printf(" DEC. v. NTRU 3 Ronda (SW) \t ... \t (%6llu us.) \n \n", tiempo_total_dec / (unsigned long long)N_TEST);
	printf(" ACELERACION Mult.:  %f \n", (float)tiempo_total_enc_1 / (float)tiempo_total_enc_hw);
	printf(" ACELERACION ENC:  %f \n \n", (float)tiempo_total_enc_1 / (float)tiempo_total_enc_hw);
	printf(" FALLOS_SW: %d \n", fallos);
	printf(" FALLOS_HW: %d \n", fallos_HW);
	printf(" FALLOS_CRYPTO: %d \n \n", fallos_crypto);

	PYNQ_closeDMA(&dma);
	PYNQ_freeSharedMemory(&shm_1);
	PYNQ_freeSharedMemory(&shm_2);

	return PYNQ_SUCCESS;
}